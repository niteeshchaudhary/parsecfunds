# Getting Started

Install All Dependencies using

### `npm i`

Do Truffle Migrate using

### `truffle migrate --rest`

Open ganache and ensure it to run on 8545 port

After setting up react, ganache and truffle
Simply run the project using

### `npm start`

As Project uses Firebase so i have not remove its credentials so you can
run it on my credentials
